# Anomaly Detection in Sensor Data using an LSTM Autoencoder

Deep-learning mini project. An LSTM autoencoder is trained **only on normal
sensor behaviour**; windows it cannot reconstruct well are flagged as anomalies.

* Dataset: NAB `machine_temperature_system_failure.csv` (22,695 readings,
  5-minute interval) + official anomaly-window labels (`data/`).
* Model: 4-layer LSTM autoencoder (44,993 parameters), TensorFlow / Keras.
* Baselines: Z-score rule, Isolation Forest.

## Run
```bash
pip install -r requirements.txt
python main.py          # trains, evaluates, writes outputs/ (figures, model, results.json)
```

## Files
| File | Purpose |
|---|---|
| `data_utils.py` | loading, labelling, chronological split, windowing |
| `model.py` | LSTM autoencoder definition |
| `main.py` | training, thresholding, evaluation, baselines, figures |
| `outputs/` | figures, trained model, `results.json` |
