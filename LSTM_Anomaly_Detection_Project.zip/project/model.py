"""LSTM Autoencoder model definition."""

from tensorflow import keras
from tensorflow.keras import layers


def build_lstm_autoencoder(window, n_features=1, latent=16):
    inp = layers.Input(shape=(window, n_features))
    x = layers.LSTM(64, return_sequences=True)(inp)  # encoder
    x = layers.Dropout(0.2)(x)
    x = layers.LSTM(latent, return_sequences=False)(x)  # bottleneck
    x = layers.RepeatVector(window)(x)  # decoder
    x = layers.LSTM(latent, return_sequences=True)(x)
    x = layers.Dropout(0.2)(x)
    x = layers.LSTM(64, return_sequences=True)(x)
    out = layers.TimeDistributed(layers.Dense(n_features))(x)
    model = keras.Model(inp, out, name="lstm_autoencoder")
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss="mse")
    return model
