"""Anomaly Detection in Sensor Data using an LSTM Autoencoder.
Run:  python main.py
"""

import os, json, random
import numpy as np
import pandas as pd
import tensorflow as tf
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest
from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    precision_recall_curve,
)

from data_utils import load_data, prepare, WINDOW
from model import build_lstm_autoencoder

SEED = 42
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)
OUT = "outputs"
os.makedirs(OUT, exist_ok=True)


def recon_error(model, X):
    """Mean squared reconstruction error of every window."""
    pred = model.predict(X, batch_size=256, verbose=0)
    return np.mean((X - pred) ** 2, axis=(1, 2))


def metrics(y, pred, score):
    tn, fp, fn, tp = confusion_matrix(y, pred).ravel()
    return dict(
        precision=precision_score(y, pred, zero_division=0),
        recall=recall_score(y, pred),
        f1=f1_score(y, pred),
        roc_auc=roc_auc_score(y, score),
        tp=int(tp),
        fp=int(fp),
        fn=int(fn),
        tn=int(tn),
    )


def main():
    # 1. Data --------------------------------------------------------------
    df, windows = load_data()
    X_train, X_test, y_test, t_test, (mu, sigma) = prepare(df)
    print(
        "Train windows:",
        X_train.shape,
        "| Test windows:",
        X_test.shape,
        "| anomalous test points:",
        int(y_test.sum()),
    )

    # 2. Train LSTM-AE on NORMAL data only ---------------------------------
    model = build_lstm_autoencoder(WINDOW)
    model.summary()
    es = tf.keras.callbacks.EarlyStopping(
        monitor="val_loss", patience=4, restore_best_weights=True
    )
    hist = model.fit(
        X_train,
        X_train,
        epochs=30,
        batch_size=128,
        validation_split=0.1,
        shuffle=True,
        callbacks=[es],
        verbose=2,
    )
    model.save(f"{OUT}/lstm_autoencoder.keras")

    # 3. Threshold from training reconstruction error ----------------------
    err_train = recon_error(model, X_train)
    threshold = float(np.percentile(err_train, 99))
    print("Threshold (99th pct of train error):", threshold)

    # 4. Score test windows -------------------------------------------------
    err_test = recon_error(model, X_test)
    err_smooth = pd.Series(err_test).rolling(12, min_periods=1).mean().values
    pred = (err_smooth > threshold).astype(int)
    res_lstm = metrics(y_test, pred, err_smooth)

    # 5. Baselines ------------------------------------------------------------
    vals_tr = X_train[:, -1, 0].reshape(-1, 1)
    vals_te = X_test[:, -1, 0].reshape(-1, 1)
    z = np.abs(vals_te[:, 0])
    z_pred = (z > 3).astype(int)
    res_z = metrics(y_test, z_pred, z)

    def feats(X):  # window statistics so the baseline sees the same context
        return np.c_[
            X[:, -1, 0],
            X.mean(axis=(1, 2)),
            X.std(axis=(1, 2)),
            X[:, -1, 0] - X[:, 0, 0],
        ]

    iso = IsolationForest(
        n_estimators=200, contamination=0.01, random_state=SEED
    )
    iso.fit(feats(X_train))
    iso_score = -iso.score_samples(feats(X_test))
    iso_pred = (iso.predict(feats(X_test)) == -1).astype(int)
    res_iso = metrics(y_test, iso_pred, iso_score)

    # 6. Window-level detection (did we catch each failure window?) ----------
    ts = pd.Series(t_test)
    win_rows = []
    for s, e in windows:
        s, e = pd.Timestamp(s), pd.Timestamp(e)
        m = ((ts >= s) & (ts <= e)).values
        if m.sum() == 0:
            continue
        hit = pred[m].sum()
        first = ts[m][pred[m] == 1]
        win_rows.append(
            dict(
                window=f"{s:%d %b %Y} - {e:%d %b %Y}",
                points=int(m.sum()),
                flagged=int(hit),
                detected=bool(hit > 0),
                first_alarm=str(first.iloc[0]) if len(first) else "-",
            )
        )

    summary = dict(
        threshold=threshold,
        epochs_run=len(hist.history["loss"]),
        train_windows=int(len(X_train)),
        test_windows=int(len(X_test)),
        lstm_autoencoder=res_lstm,
        zscore=res_z,
        isolation_forest=res_iso,
        windows=win_rows,
        final_train_loss=float(hist.history["loss"][-1]),
        final_val_loss=float(hist.history["val_loss"][-1]),
    )
    json.dump(summary, open(f"{OUT}/results.json", "w"), indent=2)
    print(json.dumps(summary, indent=2))

    # 7. Figures ---------------------------------------------------------------
    plt.rcParams.update({"font.size": 10, "figure.dpi": 130})

    # Fig 1: raw data with labelled anomalies
    fig, ax = plt.subplots(figsize=(10, 3.4))
    ax.plot(df["timestamp"], df["value"], lw=0.5, color="#1f4e79")
    for i, (s, e) in enumerate(windows):
        ax.axvspan(
            pd.Timestamp(s),
            pd.Timestamp(e),
            color="red",
            alpha=0.25,
            label="Labelled anomaly window" if i == 0 else None,
        )
    ax.axvline(
        pd.Timestamp("2014-01-10"),
        ls="--",
        color="k",
        lw=1,
        label="Train/Test split",
    )
    ax.set_title(
        "Machine temperature sensor data (NAB) with labelled anomaly windows"
    )
    ax.set_ylabel("Temperature")
    ax.legend(loc="lower left")
    fig.tight_layout()
    fig.savefig(f"{OUT}/fig1_dataset.png")
    plt.close(fig)

    # Fig 2: training curves
    fig, ax = plt.subplots(figsize=(6, 3.4))
    ax.plot(hist.history["loss"], label="Train loss")
    ax.plot(hist.history["val_loss"], label="Validation loss")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("MSE")
    ax.set_title("Training and validation loss")
    ax.legend()
    fig.tight_layout()
    fig.savefig(f"{OUT}/fig2_loss.png")
    plt.close(fig)

    # Fig 3: reconstruction error distribution
    fig, ax = plt.subplots(figsize=(6, 3.4))
    ax.hist(
        np.log10(err_train + 1e-9),
        bins=60,
        alpha=0.7,
        label="Train (normal)",
        density=True,
    )
    ax.hist(
        np.log10(err_test[y_test == 1] + 1e-9),
        bins=60,
        alpha=0.6,
        label="Test (anomalous)",
        density=True,
        color="red",
    )
    ax.axvline(np.log10(threshold), color="k", ls="--", label="Threshold")
    ax.set_xlabel("log10(reconstruction error)")
    ax.set_title("Reconstruction error distribution")
    ax.legend()
    fig.tight_layout()
    fig.savefig(f"{OUT}/fig3_error_hist.png")
    plt.close(fig)

    # Fig 4: detection on test period
    fig, axes = plt.subplots(2, 1, figsize=(10, 5.4), sharex=True)
    tdt = pd.to_datetime(t_test)
    axes[0].plot(tdt, X_test[:, -1, 0] * sigma + mu, lw=0.5, color="#1f4e79")
    axes[0].scatter(
        tdt[pred == 1],
        (X_test[:, -1, 0] * sigma + mu)[pred == 1],
        s=3,
        c="red",
        label="Detected anomaly",
    )
    axes[0].fill_between(
        tdt,
        *axes[0].get_ylim(),
        where=y_test == 1,
        color="orange",
        alpha=0.25,
        label="True anomaly window",
    )
    axes[0].set_ylabel("Temperature")
    axes[0].legend(loc="lower left")
    axes[0].set_title("Anomaly detection on the test period")
    axes[1].plot(tdt, err_smooth, lw=0.7, color="purple")
    axes[1].axhline(threshold, color="k", ls="--", label="Threshold")
    axes[1].set_yscale("log")
    axes[1].set_ylabel("Recon. error (log)")
    axes[1].legend(loc="upper left")
    fig.tight_layout()
    fig.savefig(f"{OUT}/fig4_detection.png")
    plt.close(fig)

    # Fig 5: normal vs anomalous reconstruction example
    idx_norm = int(np.where(y_test == 0)[0][len(np.where(y_test == 0)[0]) // 2])
    idx_anom = int(np.where(y_test == 1)[0][np.argmax(err_test[y_test == 1])])
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.2))
    for ax, i, title in zip(
        axes, [idx_norm, idx_anom], ["Normal window", "Anomalous window"]
    ):
        rec = model.predict(X_test[i : i + 1], verbose=0)[0, :, 0]
        ax.plot(X_test[i, :, 0] * sigma + mu, label="Original")
        ax.plot(rec * sigma + mu, "--", label="Reconstructed")
        ax.set_title(f"{title} (error={err_test[i]:.4f})")
        ax.set_xlabel("Time step")
        ax.legend()
    fig.tight_layout()
    fig.savefig(f"{OUT}/fig5_reconstruction.png")
    plt.close(fig)

    # Fig 6: confusion matrix
    cm = confusion_matrix(y_test, pred)
    fig, ax = plt.subplots(figsize=(3.8, 3.4))
    ax.imshow(cm, cmap="Blues")
    for (i, j), v in np.ndenumerate(cm):
        ax.text(
            j,
            i,
            str(v),
            ha="center",
            va="center",
            color="white" if v > cm.max() / 2 else "black",
        )
    ax.set_xticks([0, 1], ["Normal", "Anomaly"])
    ax.set_yticks([0, 1], ["Normal", "Anomaly"])
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title("Confusion matrix (LSTM-AE)")
    fig.tight_layout()
    fig.savefig(f"{OUT}/fig6_confusion.png")
    plt.close(fig)


if __name__ == "__main__":
    main()
