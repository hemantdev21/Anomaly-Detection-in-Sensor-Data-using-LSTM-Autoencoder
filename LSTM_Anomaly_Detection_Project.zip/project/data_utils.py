"""Data loading, labelling and windowing utilities for the
LSTM-Autoencoder anomaly-detection project (NAB machine temperature data)."""

import json
import numpy as np
import pandas as pd

DATA_CSV = "data/machine_temperature.csv"
LABELS_JSON = "data/combined_windows.json"
LABEL_KEY = "realKnownCause/machine_temperature_system_failure.csv"
WINDOW = 36  # 36 steps x 5 min = 3 hours of context
SPLIT_DATE = "2014-01-10"  # everything before -> training period


def load_data():
    """Load the sensor series and attach a 0/1 ground-truth anomaly label."""
    df = pd.read_csv(DATA_CSV, parse_dates=["timestamp"])
    with open(LABELS_JSON) as f:
        windows = json.load(f)[LABEL_KEY]
    df["label"] = 0
    for start, end in windows:
        mask = (df["timestamp"] >= pd.Timestamp(start)) & (
            df["timestamp"] <= pd.Timestamp(end)
        )
        df.loc[mask, "label"] = 1
    return df, windows


def make_sequences(values, window=WINDOW):
    """Sliding windows (stride 1). Output shape: (n, window, 1)."""
    seqs = np.lib.stride_tricks.sliding_window_view(values, window)
    return seqs[..., np.newaxis].astype("float32")


def prepare(df, window=WINDOW):
    """Chronological split. Only NORMAL windows are used for training."""
    split_idx = int((df["timestamp"] < pd.Timestamp(SPLIT_DATE)).sum())
    train_df, test_df = df.iloc[:split_idx], df.iloc[split_idx:]

    mu, sigma = train_df["value"].mean(), train_df["value"].std()
    scale = lambda x: ((x - mu) / sigma).values

    X_train_all = make_sequences(scale(train_df["value"]), window)
    # a window is 'normal' only if none of its points is labelled anomalous
    lab_train = np.lib.stride_tricks.sliding_window_view(
        train_df["label"].values, window
    ).max(axis=1)
    X_train = X_train_all[lab_train == 0]

    X_test = make_sequences(scale(test_df["value"]), window)
    y_test = test_df["label"].values[window - 1 :]  # label of last point
    t_test = test_df["timestamp"].values[window - 1 :]
    return X_train, X_test, y_test, t_test, (mu, sigma)
